package test.java.com.conference.management;

import org.junit.Assert;
import org.junit.Test;

import com.management.ProposalSessionDetails;
import com.management.ProposalTimeFitInToSlot;
import com.management.ProposalUtils.ProposalUtility;

import java.util.Calendar;

public class ProposalFitTest {

	
	
    @Test
    public void validTalk(){
    	Calendar slotStartTime = ProposalUtility.getCalendarTime(9, 00);
        ProposalTimeFitInToSlot slot = new ProposalTimeFitInToSlot(50, slotStartTime);

        ProposalSessionDetails talk1 = new ProposalSessionDetails("Proposal Talk Duration is Valid", 49);
        Assert.assertTrue(slot.hasRoomFor(talk1));
    }
    
    @Test
    public void validTalk1(){
    	Calendar slotStartTime = ProposalUtility.getCalendarTime(9, 00);
        ProposalTimeFitInToSlot slot = new ProposalTimeFitInToSlot(57, slotStartTime);

        ProposalSessionDetails talk1 = new ProposalSessionDetails("Proposal Talk Duration is Valid", 55);
        Assert.assertTrue(slot.hasRoomFor(talk1));
    }
    
    @Test
    public void validTalk2(){
    	Calendar slotStartTime = ProposalUtility.getCalendarTime(9, 00);
        ProposalTimeFitInToSlot slot = new ProposalTimeFitInToSlot(45, slotStartTime);

        ProposalSessionDetails talk1 = new ProposalSessionDetails("Proposal Talk Duration is Valid", 39);
        Assert.assertTrue(slot.hasRoomFor(talk1));
    }
    
    @Test
    public void inValidTalksUnMatchTime(){
    	Calendar slotStartTime = ProposalUtility.getCalendarTime(9, 00);
        ProposalTimeFitInToSlot slot = new ProposalTimeFitInToSlot(50, slotStartTime);

        ProposalSessionDetails talk2 = new ProposalSessionDetails("Proposal Talk Duration is Invalid", 51);
        Assert.assertFalse(slot.hasRoomFor(talk2));
        
    }
    
    @Test
    public void inValidTalksUnMatchTime1(){
    	Calendar slotStartTime = ProposalUtility.getCalendarTime(9, 00);
        ProposalTimeFitInToSlot slot = new ProposalTimeFitInToSlot(45, slotStartTime);

        ProposalSessionDetails talk2 = new ProposalSessionDetails("Proposal Talk Duration is Invalid", 46);
        Assert.assertFalse(slot.hasRoomFor(talk2));
        
    }
    
    @Test
    public void inValidTalksUnMatchTime2(){
    	Calendar slotStartTime = ProposalUtility.getCalendarTime(9, 00);
        ProposalTimeFitInToSlot slot = new ProposalTimeFitInToSlot(60, slotStartTime);

        ProposalSessionDetails talk2 = new ProposalSessionDetails("Proposal Talk Duration is Invalid", 61);
        Assert.assertFalse(slot.hasRoomFor(talk2));
        
    }
}

package test.java.com.conference.management;

import org.junit.Assert;
import org.junit.Test;

import com.management.ProposalSessionDetails;
import com.management.ProposalUtils.ProposalUtility;

import java.util.Calendar;

public class ConferenceUtilsTest {


    @Test
    public void testProposalGetCalTime() {

        Calendar cal1 = ProposalUtility.getCalendarTime(6, 15);

        Calendar cal2 = Calendar.getInstance();
        cal2.set(Calendar.HOUR_OF_DAY, 6);
        cal2.set(Calendar.MINUTE, 15);
        Assert.assertEquals(cal1.get(Calendar.HOUR_OF_DAY), cal2.get(Calendar.HOUR_OF_DAY));
        Assert.assertEquals(cal1.get(Calendar.MINUTE), cal2.get(Calendar.MINUTE));

        cal1 = ProposalUtility.getCalendarTime(4, 30);
        cal2 = Calendar.getInstance();
        cal2.set(Calendar.HOUR_OF_DAY, 4);
        cal2.set(Calendar.MINUTE, 30);

        Assert.assertEquals(cal1.get(Calendar.HOUR_OF_DAY), cal2.get(Calendar.HOUR_OF_DAY));
        Assert.assertEquals(cal1.get(Calendar.MINUTE), cal2.get(Calendar.MINUTE));
        
        cal1 = ProposalUtility.getCalendarTime(4, 30);
        cal2 = Calendar.getInstance();
        cal2.set(Calendar.HOUR_OF_DAY, 5);
        cal2.set(Calendar.MINUTE, 45);

        Assert.assertNotSame(cal1.get(Calendar.HOUR_OF_DAY), cal2.get(Calendar.HOUR_OF_DAY));
        Assert.assertNotSame(cal1.get(Calendar.MINUTE), cal2.get(Calendar.MINUTE));
        
        cal1 = ProposalUtility.getCalendarTime(7, 00);
        cal2 = Calendar.getInstance();
        cal2.set(Calendar.HOUR_OF_DAY, 6);
        cal2.set(Calendar.MINUTE, 59);

        Assert.assertNotSame(cal1.get(Calendar.HOUR_OF_DAY), cal2.get(Calendar.HOUR_OF_DAY));
        Assert.assertNotSame(cal1.get(Calendar.MINUTE), cal2.get(Calendar.MINUTE));

    }

    @Test
    public void testProposalNextStartTime() {
        Calendar currentStartTime = ProposalUtility.getCalendarTime(5, 00);
        ProposalSessionDetails talk = new ProposalSessionDetails("ProposalSession Talk test", 30);

        Calendar nextStartTimeManual = ProposalUtility.getCalendarTime(5, 30);
        Calendar nextStartTimeCalculated = ProposalUtility.getNextStartTime(currentStartTime, talk);

        Assert.assertEquals(nextStartTimeManual.get(Calendar.HOUR_OF_DAY), nextStartTimeCalculated.get(Calendar.HOUR_OF_DAY));
        Assert.assertEquals(nextStartTimeManual.get(Calendar.MINUTE), nextStartTimeCalculated.get(Calendar.MINUTE));
    }
    
    @Test
    public void testProposalNextStartTimeWithDifferentData() {
        Calendar currentStartTime = ProposalUtility.getCalendarTime(6, 30);
        ProposalSessionDetails talk = new ProposalSessionDetails("ProposalSession Talk test", 30);

        Calendar nextStartTimeManual = ProposalUtility.getCalendarTime(7, 00);
        Calendar nextStartTimeCalculated = ProposalUtility.getNextStartTime(currentStartTime, talk);

        Assert.assertEquals(nextStartTimeManual.get(Calendar.HOUR_OF_DAY), nextStartTimeCalculated.get(Calendar.HOUR_OF_DAY));
        Assert.assertEquals(nextStartTimeManual.get(Calendar.MINUTE), nextStartTimeCalculated.get(Calendar.MINUTE));
    }
}

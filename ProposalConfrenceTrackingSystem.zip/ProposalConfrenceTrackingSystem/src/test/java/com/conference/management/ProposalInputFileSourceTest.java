package test.java.com.conference.management;


import org.junit.Assert;
import org.junit.Test;

import com.management.ProposalSessionDetails;
import com.management.FileInputOut.ConferenceFileSourceManager;

import java.io.FileNotFoundException;
import java.util.List;

public class ProposalInputFileSourceTest {

    ConferenceFileSourceManager manager = new ConferenceFileSourceManager();

    @Test
    public void testNoOfTalks4() throws FileNotFoundException {
        List<ProposalSessionDetails> talks = manager.fetchTalks("Input-Confrence-parameters-4-session.txt");
        Assert.assertEquals(4, talks.size());
    }
    
    @Test
    public void testNoOfTalks10() throws FileNotFoundException {
        List<ProposalSessionDetails> talks = manager.fetchTalks("Input-Confrence-parameters-10-session.txt");
        Assert.assertEquals(10, talks.size());
    }
    
    @Test
    public void testNoOfTalksNotEqualToInputTalksParameter() throws FileNotFoundException {
        List<ProposalSessionDetails> talks = manager.fetchTalks("Input-Confrence-parameters-10-session.txt");
        Assert.assertNotSame(6, talks.size());
    }


    @Test
    public void testNoOfInputTalk0WithEmptyFile() throws FileNotFoundException {
        List<ProposalSessionDetails> talks = manager.fetchTalks("Input-Confrence-parameters-empty.txt");
        Assert.assertEquals(0, talks.size());
    }


    @Test(expected = FileNotFoundException.class)
    public void testWhenFileNotFoundOrNotAValidFile() throws FileNotFoundException {
        List<ProposalSessionDetails> talks = manager.fetchTalks("Input-Confrence-parameters123.txt");
    }
   

}
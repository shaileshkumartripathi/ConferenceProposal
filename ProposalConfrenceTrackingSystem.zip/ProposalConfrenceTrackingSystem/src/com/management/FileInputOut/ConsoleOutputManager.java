package com.management.FileInputOut;


import java.text.SimpleDateFormat;
import java.util.List;

import com.management.ConferenceParameters;
import com.management.ProposalConferenceSession;
import com.management.ProposalTimeFitInToSlot;
import com.management.ProposalNumberOfTracksCount;
import com.management.core.ProposalConferenceConfig;

public class ConsoleOutputManager {

    public void printSchedule (ConferenceParameters conference) {

        SimpleDateFormat sdf = ProposalConferenceConfig.DATE_FORMAT;
        System.out.println("Output: Conference Schedule :");
        System.out.println("--------------------------------------------------------");
        for(ProposalNumberOfTracksCount track : conference.getTracks()){
            System.out.println("Track " + track.getTrackId());
            List<ProposalTimeFitInToSlot> slots = track.getSlots();
            System.out.println("");

            // Output the talks into tracks based on the totalTalks and the count of Talks.
            for (ProposalTimeFitInToSlot slot : slots) {

                for (ProposalConferenceSession event : slot.getEvents()) {
                    // Print the prepared talk's title for this Track
                    System.out.println(sdf.format(event.getStartTime().getTime()) + " " + event.getTitle()
                            + " " + event.getDurationInMinutes());
                }
            }
            System.out.println("--------------------------------------------------------");
        }
    }

}

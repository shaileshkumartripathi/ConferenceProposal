package com.management.FileInputOut;


import java.io.*;
import java.util.ArrayList;
import java.util.List;

import com.management.ProposalSessionDetails;
import com.management.core.ProposalConferenceConfig;

public class ConferenceFileSourceManager {

    public List<ProposalSessionDetails> fetchTalks(String fileName) throws FileNotFoundException{
        FileInputStream inputFile = null;
        List<ProposalSessionDetails> talkList = new ArrayList<>();

        try {
            inputFile = new FileInputStream(fileName);
        } catch (FileNotFoundException e) {
            System.err.println("Proposal File Not Found : " + ProposalConferenceConfig.TALKS_INPUT_FILE + ". Make sure the file exists");
            throw e;
        }
        BufferedReader br = new BufferedReader(new InputStreamReader(inputFile));

        String strLine;
        int intMinutes;

       
        try {
            while ((strLine = br.readLine()) != null) {
               
                if(strLine.contains("@@") || strLine.isEmpty())
                    continue;

                String title = strLine.substring(0, strLine.lastIndexOf(" "));
                String minutesString = strLine.substring(strLine.lastIndexOf(" ") + 1);
                
                String minutes = strLine.replaceAll("\\D+", "");
                if (ProposalConferenceConfig.LIGHTNING_TALK.equals(minutesString)) {
                    intMinutes = ProposalConferenceConfig.LIGHTNING_TALK_DURATION_MINUTES;
                } else {
                    try {
                        intMinutes = Integer.parseInt(minutes);
                    } catch (NumberFormatException e) {
                        System.err.println("Could not parse the line : " + strLine);
                        throw e;
                    }
                }
                ProposalSessionDetails singleTalk = new ProposalSessionDetails(title, intMinutes);
                talkList.add(singleTalk);

            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                inputFile.close();
                br.close();
            } catch (IOException e){
                System.err.println(e.getMessage());
            }
        }
        return talkList;
    }

    public List<ProposalSessionDetails> getTheProposalList() throws FileNotFoundException{
        return fetchTalks(ProposalConferenceConfig.TALKS_INPUT_FILE);
    }
}

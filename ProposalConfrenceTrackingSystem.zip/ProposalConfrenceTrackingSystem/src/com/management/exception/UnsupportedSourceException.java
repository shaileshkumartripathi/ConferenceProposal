package com.management.exception;

public class UnsupportedSourceException extends Throwable {

    public UnsupportedSourceException(String message) {
        super(message);
    }
}

package com.management.exception;

public class UnsupportedDestinationException extends Throwable {

    public UnsupportedDestinationException(String message) {
        super(message);
    }

}

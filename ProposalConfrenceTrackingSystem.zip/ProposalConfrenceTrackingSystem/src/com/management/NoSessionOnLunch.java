package com.management;



import java.text.SimpleDateFormat;

import com.management.core.ProposalConferenceConfig;

public class NoSessionOnLunch extends ProposalConferenceSession {
    public NoSessionOnLunch() {
        super(ProposalConferenceConfig.LUNCH_START_TIME, "Lunch", ProposalConferenceConfig.LUNCH_DURATION_MINUTES);
    }
}

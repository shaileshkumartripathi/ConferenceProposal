package com.management;

import java.util.ArrayList;
import java.util.List;

public class ProposalNumberOfTracksCount {
    private List<ProposalTimeFitInToSlot> slots;
    private int trackId;

    public ProposalNumberOfTracksCount(int trackId) {
        this.trackId = trackId;
        slots = new ArrayList<>();
    }

    public List<ProposalTimeFitInToSlot> getSlots() {
        return slots;
    }

    public void addSlot(ProposalTimeFitInToSlot slot) {
        this.slots.add(slot);
    }

    public int getTrackId() {
        return trackId;
    }

}

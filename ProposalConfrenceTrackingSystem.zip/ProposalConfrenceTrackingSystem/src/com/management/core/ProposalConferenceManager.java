package com.management.core;

import java.io.FileNotFoundException;
import java.util.*;

import com.management.ConferenceParameters;
import com.management.ProposalConferenceSession;
import com.management.NoSessionOnLunch;
import com.management.NetworkingTime;
import com.management.ProposalTimeFitInToSlot;
import com.management.Enum.ProposalConferenceInputFileNameEnum;
import com.management.Enum.ProposalConferenceOutputEnum;
import com.management.FileInputOut.ConferenceFileSourceManager;
import com.management.FileInputOut.ConsoleOutputManager;
import com.management.ProposalUtils.ProposalUtility;
import com.management.ProposalSessionDetails;
import com.management.ProposalConferenceSessionComparision;
import com.management.ProposalNumberOfTracksCount;
import com.management.exception.UnsupportedDestinationException;
import com.management.exception.UnsupportedSourceException;

public class ProposalConferenceManager {

    public List<ProposalSessionDetails> fetchTalksListFromSource(ProposalConferenceInputFileNameEnum dataSourceEnum) throws UnsupportedSourceException{

        // Not exactly a factory. This will create an instance of the required SourceManager
        if (dataSourceEnum.equals(ProposalConferenceInputFileNameEnum.INPUT_FILE)) {
            ConferenceFileSourceManager sourceManager = new ConferenceFileSourceManager();
            try {
                return sourceManager.getTheProposalList();
            } catch (FileNotFoundException e) {

                return null;
            }
        } else {
            throw new UnsupportedSourceException("Source type not valid");
        }
    }

    public void outputConferenceSchedule(ConferenceParameters conference, ProposalConferenceOutputEnum dataOutputEnum) throws UnsupportedDestinationException {

        // It create an instance of the required Proposal OutputManager
        if (dataOutputEnum.equals(ProposalConferenceOutputEnum.CONSOLE_OUTPUT.CONSOLE_OUTPUT)) {
            ConsoleOutputManager outputManager = new ConsoleOutputManager();
            outputManager.printSchedule(conference);
        } else {
            throw new UnsupportedDestinationException("Destination not valid.");
        }
    }


    public ConferenceParameters processAndScheduleTalks(List<ProposalSessionDetails> talkList){
        ConferenceParameters conference = new ConferenceParameters();

        // Preference to sort the order decremented.e.g 60 minute prefer then 45 minutes.
        Collections.sort(talkList, new ProposalConferenceSessionComparision());
        int trackCount = 0;

        // run this loop till all the talks are scheduled.
        while (0 != talkList.size()) {

            // create and fill morning slot.
            ProposalTimeFitInToSlot morningSlot = new ProposalTimeFitInToSlot(ProposalConferenceConfig.MORNING_SLOT_DURATION_MINUTES, ProposalConferenceConfig.TRACK_START_TIME);
            proposedSessionFitInToSolt(morningSlot, talkList);

            // create and fill lunch slot.
            ProposalTimeFitInToSlot lunchSlot = new ProposalTimeFitInToSlot(ProposalConferenceConfig.LUNCH_DURATION_MINUTES, ProposalConferenceConfig.LUNCH_START_TIME);
            lunchSlot.addEvent(new NoSessionOnLunch());

            // create and fill afternoon slot.
            ProposalTimeFitInToSlot afternoonSlot = new ProposalTimeFitInToSlot(ProposalConferenceConfig.AFTERNOON_SLOT_DURATION_MINUTES,
                    ProposalConferenceConfig.POST_LUNCH_SLOT_START_TIME);
            proposedSessionFitInToSolt(afternoonSlot, talkList);

            // create and fill networking slot.
            ProposalTimeFitInToSlot networkingSlot = new ProposalTimeFitInToSlot(ProposalConferenceConfig.NETWORKING_DURATION_MINUTES,
                    ProposalConferenceConfig.NETWORKING_START_TIME);
            networkingSlot.addEvent(new NetworkingTime());

            // add all the slots for the day into the track.
            ProposalNumberOfTracksCount track = new ProposalNumberOfTracksCount(++trackCount);
            track.addSlot(morningSlot);
            track.addSlot(lunchSlot);
            track.addSlot(afternoonSlot);
            track.addSlot(networkingSlot);
            // there are some tracks it will add the no of proposed tracks.
            conference.addTrack(track);
        }

        return conference;
    }

    private void proposedSessionFitInToSolt(ProposalTimeFitInToSlot slot, List<ProposalSessionDetails> talks) {
        // initialize the slot start time.
        Calendar currentStartTime = slot.getStartTime();
        for (Iterator<ProposalSessionDetails> talksIterator = talks.iterator(); talksIterator.hasNext();) {
            ProposalSessionDetails talk = talksIterator.next();
            if (slot.hasRoomFor(talk)) {
                // add an event to the slot at the currentStartTime calculated.
                slot.addEvent(new ProposalConferenceSession(currentStartTime, talk.getTitle(), talk.getDurationInMinutes()));
                // calculate the next start time based on the current start time and current talk duration.
                currentStartTime = ProposalUtility.getNextStartTime(currentStartTime, talk);
                // Talk has been removed from the list .It means It has been already scheduled.
                talksIterator.remove();
            }
        }
    }

}

package com.management.core;


import java.util.List;

import com.management.ConferenceParameters;
import com.management.ProposalSessionDetails;
import com.management.Enum.ProposalConferenceInputFileNameEnum;
import com.management.Enum.ProposalConferenceOutputEnum;
import com.management.ProposalUtils.ProposalUtility;
import com.management.exception.UnsupportedDestinationException;

public class StartProposalFitInToConference {

    public static void main(String[] args) {

        ProposalConferenceManager conferenceManager = new ProposalConferenceManager();
        List<ProposalSessionDetails> talkList = null;
        // Fetch the input talk list.
        try {
            talkList = conferenceManager.fetchTalksListFromSource(ProposalConferenceInputFileNameEnum.INPUT_FILE);
        } catch (com.management.exception.UnsupportedSourceException e){
            System.err.println(e.getMessage());
        }

        if(talkList == null || talkList.size() == 0)
            return;

        // Print Proposal Information.
        ProposalUtility.printTalks(talkList);

        // Process and schedule Proposal talks into events and slots.
        ConferenceParameters conference = conferenceManager.processAndScheduleTalks(talkList);

        // Output the Proposal conference events.
        try {
            conferenceManager.outputConferenceSchedule(conference, ProposalConferenceOutputEnum.CONSOLE_OUTPUT);
        } catch (UnsupportedDestinationException e){
            System.err.println(e.getMessage());
        }

    }
}

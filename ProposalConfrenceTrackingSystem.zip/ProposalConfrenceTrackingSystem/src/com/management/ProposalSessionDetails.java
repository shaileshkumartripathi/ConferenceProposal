package com.management;


public class ProposalSessionDetails {

    private int proposalDurationInMinutes;
    private String proposalTitle;

    public int getDurationInMinutes() {
        return proposalDurationInMinutes;
    }

    public String getTitle() {
        return proposalTitle;
    }

    public ProposalSessionDetails(String title, int durationInMinutes)
    {
        this.proposalDurationInMinutes = durationInMinutes;
        this.proposalTitle = title;
    }

}

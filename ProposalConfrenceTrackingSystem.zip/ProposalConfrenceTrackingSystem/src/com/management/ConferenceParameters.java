package com.management;

import java.util.*;

public class ConferenceParameters {
    List<ProposalNumberOfTracksCount> tracks;

    public List<ProposalNumberOfTracksCount> getTracks() {
        return tracks;
    }

    public void addTrack(ProposalNumberOfTracksCount track) {
        this.tracks.add(track);
    }

    public ConferenceParameters(){
        this.tracks = new ArrayList();
    }
}



package com.management;



import java.text.SimpleDateFormat;

import com.management.core.ProposalConferenceConfig;


public class NetworkingTime extends ProposalConferenceSession {

    public NetworkingTime () {
        super(ProposalConferenceConfig.NETWORKING_START_TIME, "Networking Event", 0);
    }
}

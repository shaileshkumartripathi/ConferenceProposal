package com.management.Enum;

public enum ProposalConferenceOutputEnum {
    CONSOLE_OUTPUT;
}

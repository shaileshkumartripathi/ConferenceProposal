package com.management.Enum;

public enum  ProposalConferenceInputFileNameEnum {
    INPUT_FILE;
}

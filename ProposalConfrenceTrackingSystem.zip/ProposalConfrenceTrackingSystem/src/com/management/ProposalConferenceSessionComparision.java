package com.management;

import java.util.Comparator;

public class ProposalConferenceSessionComparision implements Comparator<ProposalSessionDetails>{

    @Override
    public int compare(ProposalSessionDetails t1, ProposalSessionDetails t2) {
        if(t1.getDurationInMinutes() < t2.getDurationInMinutes()){
            return 1;
        } else {
            return -1;
        }
    }
}

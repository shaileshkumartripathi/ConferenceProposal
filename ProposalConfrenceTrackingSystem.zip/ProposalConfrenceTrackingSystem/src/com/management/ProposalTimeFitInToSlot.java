package com.management;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


public class ProposalTimeFitInToSlot {

    private List<ProposalConferenceSession> events;
    private int remainingDuration;
    private Calendar startTime;

    public List<ProposalConferenceSession> getEvents() {
        return events;
    }

    public void addEvent(ProposalConferenceSession event) {
        this.events.add(event);
        this.remainingDuration -= event.getDurationInMinutes();
    }

    public Calendar getStartTime() {
        return startTime;
    }

    public ProposalTimeFitInToSlot(int duration, Calendar startTime){
        events = new ArrayList<>();
        this.remainingDuration = duration;
        this.startTime = startTime;
    }

    // check if the talk can be accommodated in the current slot.
    public boolean hasRoomFor(ProposalSessionDetails talk) {
        return remainingDuration >= talk.getDurationInMinutes();
    }
}
